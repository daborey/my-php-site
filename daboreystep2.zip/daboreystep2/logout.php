<?php
require 'db.php';

// Auto-detect base path for redirect
if (isset($_SERVER['GOOGLE_CLOUD_RUN']) || is_dir('/mnt/storage')) {
    $basePath = '/daboreystep2';
} else {
    $basePath = '/my-php-site/daboreystep2';
}

if (isset($_SESSION['username'])) {
    log_system_event($conn, $_SESSION['username'], 'USER_LOGOUT_EXPLICIT');
}

$_SESSION = array();

if (ini_get("session.use_cookies")) {
    $params = session_get_cookie_params();
    setcookie(session_name(), '', time() - 42000,
        $params["path"], $params["domain"],
        $params["secure"], $params["httponly"]
    );
}

session_destroy();
header("Location: " . $basePath . "/index.php");
exit;
?>
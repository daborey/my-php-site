<?php
require 'db.php';

if (isset($_SERVER['GOOGLE_CLOUD_RUN']) || is_dir('/mnt/storage')) {
    $basePath = '/daboreystep2';
} else {
    $basePath = '/my-php-site/daboreystep2';
}

if (!isset($_SESSION['user_id'])) {
    header("Location: " . $basePath . "/index.php");
    exit;
}

$max_idle_seconds = 900;
if (isset($_SESSION['last_activity']) && (time() - $_SESSION['last_activity'] > $max_idle_seconds)) {
    log_system_event($conn, $_SESSION['username'], 'SESSION_TIMEOUT_EXPIRED');
    session_unset();
    session_destroy();
    header("Location: " . $basePath . "/index.php?expired=1");
    exit;
}
$_SESSION['last_activity'] = time();

$message = "";
$status = "";

function fetchUserTokens($conn, $userId) {
    $result = execute_query($conn, "SELECT id, service_name, secret_seed FROM two_factor_tokens WHERE user_id = ?", [1 => $userId]);
    return fetch_all($result);
}

if ($_SERVER["REQUEST_METHOD"] == "POST" && isset($_POST['action']) && $_POST['action'] === 'add_2fa') {
    if (!isset($_POST['csrf_token']) || $_POST['csrf_token'] !== $_SESSION['csrf_token']) {
        die("Security token validation failed.");
    }

    $service_name = trim($_POST['service_name']); 
    $secret_seed = strtoupper(preg_replace('/[^A-Za-z2-7]/', '', trim($_POST['secret_seed']))); 

    if (!empty($service_name) && !empty($secret_seed)) {
        try {
            execute_query($conn, "INSERT INTO two_factor_tokens (user_id, service_name, secret_seed) VALUES (?, ?, ?)", 
                [1 => $_SESSION['user_id'], 2 => $service_name, 3 => $secret_seed]);
            log_system_event($conn, $_SESSION['username'], '2FA_KEY_ADDED_' . strtoupper($service_name));
            $message = "2FA Token added successfully.";
            $status = "success";
        } catch (Exception $e) {
            $message = "Failed to store 2FA metadata.";
            $status = "error";
        }
    }
}

$two_factor_tokens = fetchUserTokens($conn, $_SESSION['user_id']);
?>
<!DOCTYPE html>
<html>
<head>
    <meta charset="UTF-8">
    <title>2FA Import</title>
    <script src="https://cdn.jsdelivr.net/npm/jsqr@1.4.0/dist/jsQR.js"></script>
    <script src="https://cdn.jsdelivr.net/npm/gauth-decode@0.1.1/dist/gauth-decode.min.js"></script>
</head>
<body>
    <div style="max-width:600px;margin:40px auto;padding:20px;background:#1e293b;border-radius:8px;color:#f8fafc;">
        <h2>2FA Import</h2>
        <?php if ($message) echo "<p style='color:#34d399;'>".htmlspecialchars($message)."</p>"; ?>
        
        <div style="border:2px dashed #475569;padding:20px;text-align:center;cursor:pointer;" id="drop-zone" onclick="document.getElementById('qr-file-input').click()">
            <div style="font-size:48px;">📷</div>
            <span>Click or drop QR code image</span>
            <input type="file" id="qr-file-input" accept="image/*" style="display:none;">
        </div>
        <div id="status" style="margin:10px 0;color:#94a3b8;word-break:break-all;"></div>

        <hr>

        <form method="POST" action="" id="qr-submit-form">
            <input type="hidden" name="action" value="add_2fa">
            <input type="hidden" name="csrf_token" value="<?php echo $_SESSION['csrf_token']; ?>">
            <input type="hidden" id="final-name" name="service_name">
            <input type="hidden" id="final-seed" name="secret_seed">
        </form>

        <form method="POST" action="">
            <input type="hidden" name="action" value="add_2fa">
            <input type="hidden" name="csrf_token" value="<?php echo $_SESSION['csrf_token']; ?>">
            <label>Account Name:</label>
            <input type="text" name="service_name" placeholder="e.g. Google" required style="width:100%;padding:8px;margin:5px 0;">
            <label>Secret Key:</label>
            <input type="text" name="secret_seed" placeholder="JBSWY3DPEHPK3PXP" required style="width:100%;padding:8px;margin:5px 0;">
            <button type="submit" style="width:100%;padding:10px;background:#10b981;border:none;color:white;border-radius:4px;cursor:pointer;">Save</button>
        </form>

        <hr>

        <h3>Saved Tokens</h3>
        <?php foreach ($two_factor_tokens as $token): ?>
            <div style="background:#0f172a;padding:10px;border-radius:4px;margin:5px 0;display:flex;justify-content:space-between;">
                <span><?php echo htmlspecialchars($token['service_name']); ?></span>
                <span id="code-<?php echo $token['id']; ?>" data-seed="<?php echo htmlspecialchars($token['secret_seed']); ?>">000 000</span>
                <button onclick="copyCode('code-<?php echo $token['id']; ?>')">Copy</button>
            </div>
        <?php endforeach; ?>
    </div>

    <script>
    const status = document.getElementById('status');

    document.getElementById('qr-file-input').addEventListener('change', function(e) {
        if (e.target.files.length) {
            processFile(e.target.files[0]);
        }
    });

    document.getElementById('drop-zone').addEventListener('dragover', function(e) {
        e.preventDefault();
        this.style.borderColor = '#38bdf8';
    });

    document.getElementById('drop-zone').addEventListener('dragleave', function(e) {
        e.preventDefault();
        this.style.borderColor = '#475569';
    });

    document.getElementById('drop-zone').addEventListener('drop', function(e) {
        e.preventDefault();
        this.style.borderColor = '#475569';
        if (e.dataTransfer.files.length) {
            processFile(e.dataTransfer.files[0]);
        }
    });

    function processFile(file) {
        status.textContent = "Scanning...";
        const reader = new FileReader();
        reader.onload = function(e) {
            const img = new Image();
            img.onload = function() {
                const canvas = document.createElement('canvas');
                const ctx = canvas.getContext('2d');
                canvas.width = 400;
                canvas.height = 400;
                ctx.drawImage(img, 0, 0, 400, 400);
                const data = ctx.getImageData(0, 0, 400, 400);
                const code = jsQR(data.data, data.width, data.height);
                if (code && code.data) {
                    handleDecodedText(code.data);
                } else {
                    status.textContent = "No QR code found.";
                }
            };
            img.src = e.target.result;
        };
        reader.readAsDataURL(file);
    }

    // ============================================
    // SELF-CONTAINED MIGRATION PARSER (FALLBACK)
    // ============================================
    function parseMigrationQR(text) {
        try {
            // Extract base64 data from URL
            let match = text.match(/data=([^&]+)/i);
            if (!match) {
                return null;
            }
            
            let base64Data = match[1];
            base64Data = base64Data.replace(/-/g, '+').replace(/_/g, '/');
            while (base64Data.length % 4 !== 0) {
                base64Data += '=';
            }
            
            let binaryString = atob(base64Data);
            
            // Extract all Base32 secrets (A-Z2-7, 16-32 chars)
            let secrets = binaryString.match(/[A-Z2-7]{16,32}/g);
            
            if (!secrets || secrets.length === 0) {
                return null;
            }
            
            secrets = [...new Set(secrets)];
            
            let labels = [];
            let labelMatches = binaryString.match(/([A-Za-z0-9\s@.-]{2,40})/g);
            if (labelMatches) {
                labels = labelMatches.filter(function(l) {
                    return l.length > 2 && 
                           !l.match(/^[0-9]+$/) &&
                           l.length < 50 &&
                           !l.match(/^[^A-Za-z]/);
                });
            }
            
            let results = [];
            for (let i = 0; i < secrets.length; i++) {
                let label = labels[i] || "Imported Account " + (i + 1);
                label = label.replace(/[^\x20-\x7E]/g, '').trim();
                results.push({ secret: secrets[i], label: label });
            }
            
            return results;
            
        } catch (err) {
            console.error("Migration parse error:", err);
            return null;
        }
    }

    function handleDecodedText(text) {
        status.textContent = "Decoded: " + text.substring(0, 100) + "...";

        // ============================================
        // HANDLE GOOGLE AUTHENTICATOR MIGRATION QR
        // ============================================
        if (text.toLowerCase().startsWith('otpauth-migration://')) {
            status.textContent = "Migration QR detected. Decoding...";
            
            // Try using gauth-decode library first
            if (typeof decodeMigrationUri === 'function') {
                try {
                    decodeMigrationUri(text)
                        .then(function(accounts) {
                            if (accounts && accounts.length > 0) {
                                let resultHtml = "✅ Found " + accounts.length + " account(s):<br>";
                                accounts.forEach(function(acc, idx) {
                                    let label = acc.issuer && acc.name ? acc.issuer + ":" + acc.name : (acc.issuer || acc.name || "Account " + (idx+1));
                                    resultHtml += (idx + 1) + ". " + label + "<br>";
                                });
                                resultHtml += "<br>Adding first account...";
                                status.innerHTML = resultHtml;
                                
                                let first = accounts[0];
                                let secret = first.secretBase32 || first.secret;
                                let label = first.issuer && first.name ? first.issuer + ":" + first.name : (first.issuer || first.name || "Imported");
                                
                                document.getElementById('final-name').value = label;
                                document.getElementById('final-seed').value = secret;
                                setTimeout(function() {
                                    document.getElementById('qr-submit-form').submit();
                                }, 1500);
                            } else {
                                status.textContent = "No accounts found in migration data.";
                            }
                        })
                        .catch(function(err) {
                            console.error("Library decode error:", err);
                            status.textContent = "Library decode failed. Trying fallback...";
                            tryFallbackParse(text);
                        });
                } catch(err) {
                    console.error("Library call error:", err);
                    tryFallbackParse(text);
                }
            } else {
                status.textContent = "Library not loaded. Trying fallback...";
                tryFallbackParse(text);
            }
            return;
        }

        // ============================================
        // STANDARD TOTP QR CODE
        // ============================================
        let match = text.match(/secret=([A-Z2-7]{16,32})/i);
        if (match) {
            let label = "Imported Token";
            let labelMatch = text.match(/(?:label|issuer)=([^&]+)/i);
            if (labelMatch) {
                label = decodeURIComponent(labelMatch[1]);
            }
            document.getElementById('final-name').value = label;
            document.getElementById('final-seed').value = match[1].toUpperCase();
            document.getElementById('qr-submit-form').submit();
        } else {
            let rawMatch = text.match(/([A-Z2-7]{16,32})/);
            if (rawMatch) {
                document.getElementById('final-name').value = 'Imported';
                document.getElementById('final-seed').value = rawMatch[1].toUpperCase();
                document.getElementById('qr-submit-form').submit();
            } else {
                status.textContent = "No valid secret found.";
            }
        }
    }

    // ============================================
    // FALLBACK PARSER (when library fails)
    // ============================================
    function tryFallbackParse(text) {
        let accounts = parseMigrationQR(text);
        
        if (accounts && accounts.length > 0) {
            let resultHtml = "✅ Found " + accounts.length + " account(s) (fallback):<br>";
            accounts.forEach(function(acc, idx) {
                resultHtml += (idx + 1) + ". " + acc.label + "<br>";
            });
            resultHtml += "<br>Adding first account...";
            status.innerHTML = resultHtml;
            
            let first = accounts[0];
            document.getElementById('final-name').value = first.label;
            document.getElementById('final-seed').value = first.secret;
            setTimeout(function() {
                document.getElementById('qr-submit-form').submit();
            }, 1500);
        } else {
            status.textContent = "Could not parse migration QR. Try using Option 3.";
        }
    }

    function copyCode(id) {
        const code = document.getElementById(id).innerText.replace(' ', '');
        navigator.clipboard.writeText(code);
    }

    function generateTokens() {
        document.querySelectorAll('[id^="code-"]').forEach(el => {
            const seed = el.getAttribute('data-seed');
            try {
                if (typeof OTPAuth !== 'undefined') {
                    const totp = new OTPAuth.TOTP({ secret: seed });
                    const token = totp.generate();
                    el.innerText = token.substr(0,3) + ' ' + token.substr(3);
                }
            } catch(e) {}
        });
    }

    function loadOTPAuth() {
        if (typeof OTPAuth === 'undefined') {
            const script = document.createElement('script');
            script.src = 'https://cdn.jsdelivr.net/npm/otpauth@9.3.6/dist/otpauth.umd.min.js';
            script.onload = generateTokens;
            document.head.appendChild(script);
        } else {
            generateTokens();
        }
    }

    loadOTPAuth();
    setInterval(generateTokens, 30000);
    </script>
</body>
</html>